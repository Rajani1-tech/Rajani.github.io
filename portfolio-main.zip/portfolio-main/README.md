# Portfolio

## About
This site contains all my data analytics/data science projects.

## Accessing the Site

To navigate to the site [Click here](https://georgeselkassouf.github.io/portfolio)
